<?php
/**
 * Name: Blackbaud Theme Updater
 * Author: Blackbaud, Inc.
 * Version: 1.0.0
 */
namespace blackbaud;
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class ThemeUpdater {

    private $defaults = array(
        "endpoint" => "//api.blackbaud.com/services/wordpress/updater/themes",
        "force_update" => false
    );
    private $settings;
    private $endpoint;
    private $theme_data;
    private $latest_package;

    public function __construct($options = array()) {
        if (!is_admin()) {
            return;
        }
        if (empty($this->defaults)){
            $this->defaults = array();
        }
        $this->settings = array_merge($this->defaults, $options);
        $this->make_properties($this->settings);
        if ($this->force_update) {
            set_site_transient('update_themes', null);
        }
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https:" : "http:";
        $this->endpoint = $protocol . $this->endpoint;
        $this->theme_data = wp_get_theme();
        add_filter('pre_set_site_transient_update_themes', array($this, 'check_for_update'));
    }

    public function check_for_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
        if ($this->is_update_available()) {
            $theme_slug = $this->theme_data->get_template();
            $transient->response[$theme_slug] = array(
                'new_version' => $this->latest_package->version,
                'package' => $this->latest_package->package_url,
                'url' => $this->latest_package->description_url
            );
        }
        return $transient;
    }

    private function is_update_available() {
        if ($package = $this->fetch_latest_package()) {
            if (version_compare($package->version, $this->theme_data->Version, '>')) {
                return true;
            }
        }
        return false;
    }

    private function fetch_latest_package() {
        if (isset($this->latest_package)) {
            return $this->latest_package;
        }
        $response = wp_remote_get($this->endpoint . '?theme=' . $this->theme_data->get_template());
        if (is_wp_error($response)) {
            return false;
        }
        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body);
        if ($this->is_response_error($result)) {
            return false;
        }
        $this->latest_package = $result;
        $this->latest_package->package_url = $this->endpoint . '/' . $this->latest_package->zip_file;
        return $this->latest_package;
    }

    private function is_response_error($response) {
        if ($response === false) {
            return true;
        }
        if (! is_object($response)) {
            return true;
        }
        if (isset($response->error)) {
            return true;
        }
        return false;
    }

    private function make_properties($args = array()) {
        foreach ($args as $key => $val) {
            if (! isset($val)) {
                continue;
            }
            $this->$key = $val;
        }
    }
}
