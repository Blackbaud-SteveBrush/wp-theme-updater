<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

# Include these lines anywhere in your theme's functions.php.
include 'lib/theme-updater.php';
new blackbaud\ThemeUpdater(array(
    'endpoint' => '//localhost:8888/wordpress/updater/themes',
    'force_update' => true
));
