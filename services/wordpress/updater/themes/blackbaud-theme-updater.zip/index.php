<!doctype>
<html>
    <head>
        <title>Blackbaud Theme Updater</title>
        <?php wp_head(); ?>
    </head>
    <body>
        <h1>Blackbaud Theme Updater</h1>
        <?php wp_footer(); ?>
    </body>
</html>
